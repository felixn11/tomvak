/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui;

import java.awt.Color;

/**
 *
 * @author Maja Pesic
 */
public class BankRequestCellRenderer extends ColorRenderer {

        @Override
        protected Color getColor() {
            return new Color(222, 215, 255);
        }
}
