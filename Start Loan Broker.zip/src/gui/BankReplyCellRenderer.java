/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui;

import java.awt.Color;

/**
 *
 * @author Maja Pesic
 */
public class BankReplyCellRenderer extends ColorRenderer {

        @Override
        protected Color getColor() {

            return new Color(176, 167, 255);
        }
}
