/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui;

import java.awt.Color;

/**
 *
 * @author mpesic
 */
public class CreditRequestCellRenderer extends ColorRenderer {
    @Override
    protected Color getColor() {
        return new Color(255, 204, 153);
    }
}
