/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.awt.Color;

/**
 *
 * @author Maja Pesic
 */
public class ClientRequestCellRenderer extends ColorRenderer {

    @Override
    protected Color getColor() {
        return new Color(204, 255, 204);
    }
}
