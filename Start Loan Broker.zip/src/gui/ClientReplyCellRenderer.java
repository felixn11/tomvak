/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui;

import java.awt.Color;

/**
 *
 * @author Administrator
 */
public class ClientReplyCellRenderer extends ColorRenderer {

//        public ReplyRenderer() {
//            super();
//        }

        @Override
        protected Color getColor() {
            return new Color(177, 214, 177);
        }
}
